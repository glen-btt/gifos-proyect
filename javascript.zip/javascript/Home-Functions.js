////////////////////////////////////////////////////
// START STYLE BUTTON! night and day theme change
function swapStyleSheet(sheet){
    document.getElementById("pagestyle").setAttribute("href", sheet);
}

/* When the user clicks on the button, toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("actions").classList.toggle("show");
}

/* Close the dropdown if the user clicks outside of it*/
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("mini-menu");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
// END STYLE BUTTON! night and day theme change
////////////////////////////////////////////////////

////////////////////////////////////////////////////
// START TRENDS HOME SECTION! 1ST BLOCK

/*Variables to get trending items*/
var url="https://api.tenor.com/v1/search";
var query = "?q=";
var myTrendTerm = document.getElementById("word");
var apikey = "key=8DHPDNFIFMH9";

//calling the API info - FUNCTION for first section
function getTrends(){
    const found = fetch(url+query+myTrendTerm+apikey)
    .then(function(response){
      return response.json();
    })
    .then(function(myJson){
      var data = myJson;

      //linking content to HTML
      document.getElementById("preview_gif").src = data.results[0].media[0].tinygif.url;
      document.getElementById("button-trend-1").href = data.results[0].url;

      document.getElementById("preview_gif1").src = data.results[1].media[0].tinygif.url;
      document.getElementById("button-trend-2").href = data.results[1].url;

      document.getElementById("preview_gif2").src = data.results[2].media[0].tinygif.url;
      document.getElementById("button-trend-3").href = data.results[2].url;

      document.getElementById("preview_gif3").src = data.results[3].media[0].tinygif.url;
      document.getElementById("button-trend-4").href = data.results[3].url;
      console.log(myJson);
    })
    .catch(function(error){
    console.log("There was an error with fetch")
    })

    return found;
  }

//conecting to HTML

getTrends();

//function to








//END TRENDS HOME SECTION! 1ST BLOCK
////////////////////////////////////////////////////

