////////////////////////////////////////////////////
// START SEARCH BUTTON! normal or disable style
var button = document.getElementById("search-button");

function swapStyleButton(searchText){
  searchText.addEventListener("keyup", e => {
    var searchInput = e.target.value;
    console.log(searchInput)

    if(searchInput.value != '')
    {
      button.enabled = true; //button available
      const searchIcon = document.getElementById('searchIcon');
      searchIcon.src = "../assets/lupa.svg";
    } else {
      button.disabled = false; //button not available
      const searchIcon = document.getElementById('searchIcon');
      searchIcon.src = "../assets/lupa_light.svg";
  }
  });
}
// END SEARCH BUTTON! normal or disable style
////////////////////////////////////////////////////

////////////////////////////////////////////////////
// START SEARCH BUTTON FUNCTION! 
/* When the user clicks on the button, search what he wrote*/
var url="https://api.tenor.com/v1/search";
var query = "?q=";
var myTrendTerm = document.getElementById("word");
var apikey = "key=8DHPDNFIFMH9";


//this is a function if you want to enter instead of clicking the button
var searchText= document.getElementById("searchText");
searchText.addEventListener("keyup", function(event){
  if (event.keyCode === 13) {
   event.searchFunction();
   document.getElementById("search-button").click();
  }
}); //NOT WORKING!


/* When the user clicks on the button, search what he wrote*/
function searchFunction(){
  var apiUrl="https://api.tenor.com/v1/search"; //local type
  var searchText= document.getElementById("searchText").value; //gets the text in the input bar
  searchText = searchText.replace(/\s+/g, '-').toLowerCase(); //spaces replaced with hyphens
  var url = apiUrl + query + searchText + "&api_" + apikey;
  
  console.log(url)

  fetch(url)
  .then(function(response){
    return response.json();
  })
  .then(function(myJson){
    var searchResults = myJson;

    //linking content to HTML missing !!!!
    console.log(searchResults);

    function glenda() { 
    for(var i=0;i<10;i++){
      var src = searchResults.results[i].media[i].tinygif.url;
      console.log(src)     
    }
  }
  glenda();

  
  
    /*for(var i=0;i<searchResults.results.lenght;i++){
      var img = document.createElement ('img');
      img.src = searchResults.results[i].media[i].tinygif.url;
      var out = document.getElementById('trend-imgs');
      out.appendChild(img);

      FUNCIONAA
      var img = document.createElement('img');
    img.src = searchResults.results[0].media[0].tinygif.url;
    var out = document.getElementById('gifs-img-block123');
    out.appendChild(img);
      }*/

  })
 .catch(function(error){
 console.log("There was an error with fetch")
})
}

/*function printInHtml(MyJson){
  for(var i=0;i<myJson.result.lenght;i++){
    createImg(result.results[i].media[i].tinygif.url);
  }
}*/

////////////////////////////////////////////////////
// START SEARCH BUTTON FUNCTION! 
/* When the user clicks on the button, search what he wrote*/

/// TRENDING SECTION//
//VARIABLES to get trending items!!!!!!!!!!!!

