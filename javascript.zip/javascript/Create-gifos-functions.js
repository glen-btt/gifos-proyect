console.log("glenda");


//alert ("Para comenzar a grabar tu gif por favor autoriza a la cámara en la siguiente pantalla");

// To start the camara like a preview

function getStreamAndRecord() {
    navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
        height: { max: 480 }
        }
    })
    .then(function(stream){
    video.srcObject = stream;
    video.play()
    })
    .catch(function(error) {
        alert('No se ha logrado capturar tu imagen.Por favor revisa los permisos');
        console.error(error);
    })
};
    
// To start recording and it creates the stop button




// To save the recording as a gif